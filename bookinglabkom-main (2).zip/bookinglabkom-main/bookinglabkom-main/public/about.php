<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About – Booking Lab</title>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

    body {
        margin: 0;
        overflow-x: hidden;
        font-family: "Poppins", sans-serif;
        background: #04010f;
        color: white;
        scroll-behavior: smooth;
    }

    /* ANIMASI GRADIENT BACKGROUND */
    body::before {
        content:"";
        position: fixed;
        inset: 0;
        background: linear-gradient(120deg, #2d00f7, #8a00d4, #00b4ff);
        background-size: 300% 300%;
        animation: gradientMove 12s ease infinite;
        z-index:-2;
    }
    @keyframes gradientMove {
        0% {background-position: 0% 50%;}
        50% {background-position: 100% 50%;}
        100% {background-position: 0% 50%;}
    }

    /* PARTIKEL */
    #particles {
        position: fixed;
        inset: 0;
        z-index:-1;
        pointer-events:none;
        overflow:hidden;
    }
    .particle {
        position: absolute;
        width: 6px; height: 6px;
        border-radius: 50%;
        background: rgba(255,255,255,0.6);
        box-shadow: 0 0 12px #9d00ff, 0 0 20px #0077ff;
        animation: floatUp linear infinite;
    }
    @keyframes floatUp {
        0% {transform: translateY(100vh) scale(0.5); opacity:1;}
        100% {transform: translateY(-10vh) scale(1.2); opacity:0;}
    }

    /* SPLASH LOGO */
    #intro {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 999;
        animation: fadeOut 2s ease 3s forwards;
    }
    #intro img {
        width: 200px;
        opacity: 0;
        animation: zoomFlash 2.5s ease forwards;
        filter: drop-shadow(0 0 25px #7700ff);
    }
    @keyframes zoomFlash {
        0% {transform: scale(0.1); opacity:0;}
        70% {transform: scale(1.15); opacity:1;}
        100% {transform: scale(1); opacity:1;}
    }
    @keyframes fadeOut {
        to { opacity: 0; visibility: hidden; }
    }

    /* LOGO PINDAH KE POJOK */
    #floatingLogo {
        position: fixed;
        top: 20px;
        right: 25px;
        width: 65px;
        opacity: 0;
        transition: 1.2s;
        z-index: 800;
        filter: drop-shadow(0 0 15px #9800ff);
    }
    #floatingLogo.show { opacity: 1; transform: scale(1.1); }

    /* CONTENT AWAL */
    .content {
        padding: 140px 40px;
        max-width: 900px;
        margin: auto;
        text-align: center;
        min-height: 80vh;
    }

    .animate-text {
        opacity: 0;
        transform: translateY(30px);
        animation: slideUp 1.4s ease forwards;
        animation-delay: 4s;
    }
    @keyframes slideUp {
        to { opacity: 1; transform: translateY(0); }
    }

    h1 {
        font-size: 42px;
        font-weight: 700;
        background: linear-gradient(45deg, #00d9ff, #b300ff);
        -webkit-background-clip: text;
        color: transparent;
    }

    /* SECTION LANJUTAN */
    .section-more {
        padding: 100px 30px;
        max-width: 900px;
        margin: auto;
        text-align: center;
        opacity: 0;
        transform: translateY(40px);
        transition: 1.4s ease;
    }

    .section-more.show {
        opacity: 1;
        transform: translateY(0);
    }

    /* BUTTON LANJUT */
    .btn-next {
        margin-top: 30px;
        padding: 12px 26px;
        background: linear-gradient(45deg, #007bff, #b300ff);
        border: none;
        border-radius: 8px;
        cursor: pointer;
        color: white;
        font-size: 18px;
        font-weight: 600;
        box-shadow: 0 0 15px #6f00ff;
        transition: 0.3s;
    }

    .btn-next:hover {
        box-shadow: 0 0 25px #b300ff;
        transform: scale(1.05);
    }

</style>
</head>

<body>

<!-- PARTIKEL -->
<div id="particles"></div>

<!-- SPLASH LOGO -->
<div id="intro">
    <img src="assets/img/clikmerev.jpeg" alt="Logo">
</div>

<!-- LOGO KECIL POJOK -->
<img id="floatingLogo" src="assets/img/clikmerev.jpeg">
<!-- SECTION 1 -->
<div class="content">
    <h1 class="animate-text">Tentang Aplikasi Booking Laboratorium</h1>
    <p class="animate-text" style="font-size:18px;margin-top:25px;">
        Aplikasi ini dibuat untuk membantu siswa dan guru melakukan pemesanan
        laboratorium dengan cepat, mudah, dan modern.
    </p>

    <button class="btn-next" onclick="showMore()">Lanjutkan</button>
</div>

<!-- SECTION 2 (MUNCUL KETIKA DI-SCROLL ATAU TOMBOL DIKLIK) -->
<div id="more" class="section-more">
    <h2 style="color:#9cd6ff;">Deskripsi Lanjutan</h2>
    <p style="font-size:18px;margin-top:10px;">
        Sistem ini dikembangkan dengan teknologi terbaru, tampilan futuristik
        biru-ungu, dan animasi interaktif supaya pengguna merasa nyaman dan betah.
        <br><br>
        Dengan visual modern dan pengalaman pengguna yang menyenangkan, aplikasi ini
        diharapkan menjadi standar baru dalam sistem pemantauan dan booking lab komputer.
    </p>
</div>

<script>
    /* PARTIKEL */
    const container = document.getElementById("particles");
    for (let i = 0; i < 60; i++) {
        const p = document.createElement("div");
        p.classList.add("particle");
        p.style.left = Math.random() * 100 + "vw";
        p.style.animationDuration = 5 + Math.random()*10 + "s";
        container.appendChild(p);
    }

    /* LOGO KE POJOK */
    setTimeout(() => {
        document.getElementById("floatingLogo").classList.add("show");
    }, 3500);

    /* TOMBOL SHOW MORE */
    function showMore() {
        document.getElementById("more").classList.add("show");
        document.getElementById("more").scrollIntoView({behavior:"smooth"});
    }

    /* AUTO SHOW WHEN SCROLL */
    window.addEventListener("scroll", () => {
        const section = document.getElementById("more");
        const position = section.getBoundingClientRect().top;
        if (position < window.innerHeight - 150) {
            section.classList.add("show");
        }
    });
</script>

</body>
</html>
