<?php
session_start();
require_once '../config/config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  $username = $_POST['username'];
  $password = $_POST['password'];

  $query = "SELECT * FROM users WHERE username='$username' and password=md5('$password')";
  $result=$conn->query($query);
  $row = $result->num_rows;
  if($row>0){
    $data = $result->fetch_assoc();
    $_SESSION['id'] = $data['id'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['role'] = $data['role'];

    if($data['role']=='admin'){
      header("Location: admin/dashboard.php");
    } else {
      header("Location: user/dashboard.php");
    }
    echo "<script>alert('Login berhasil');</script>";
  } else {
    echo "<script>alert('Login gagal: Cek username dan password Anda'); window.location='login.php';</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Booking Labkom</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: #f3f6fa;
}

.login-wrapper {
    max-width: 900px;
    margin: 60px auto;
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.left-box {
    background: #ffffff;
    padding: 40px;
    text-align: center;
}

.left-box img {
    width: 80%;
    max-width: 260px;
}

.left-box h2 {
    font-weight: 700;
    margin-top: 15px;
}

.right-box {
    padding: 40px 50px;
}

.input-group-text {
    background: #e9ecef;
}

@media (max-width: 768px){
    .login-wrapper {
        margin: 20px;
    }
    .left-box {
        padding: 30px 20px;
    }
    .right-box {
        padding: 30px;
    }
}
</style>

</head>
<body>

<div class="login-wrapper d-flex flex-wrap">


    <div class="col-md-5 left-box d-flex flex-column justify-content-center">
        <a href="about.php"><img src="assets/img/clickmelog.jpeg" alt="Logo"></a>
    </div>

 
    <div class="col-md-7 right-box">

        <h3 class="mb-4 fw-bold text-primary">Sign In</h3>

        <form action="" method="POST">

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-user"></i></span>
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-lock"></i></span>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <button class="btn btn-primary w-100 mt-3">Login</button>

            <div class="text-center mt-3">
                <a href="forgot-password.php">Forgot password?</a> |
                <a href="register.php">Register</a>
            </div>

        </form>
    </div>

</div>

</body>
</html>
