<?php
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'user' )  {
    header("Location: ../login.php");
    exit();
}