<nav class="navbar navbar-light bg-white shadow-sm fixed-top">
    <div class="container-fluid">

        <!-- Tombol buka sidebar -->
        <button class="btn btn-outline-secondary me-2" 
            data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu">
            <i class="bi bi-list"></i>
        </button>

        <span class="navbar-brand mb-0 h1">Dashboard Admin</span>

        <div class="d-flex align-items-center">
            <span class="me-3 fw-semibold">Halo, Admin</span>
        </div>
    </div>
</nav>
