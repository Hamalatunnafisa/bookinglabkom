<?php
session_start();
require_once '../../config/config.php';

// **Cek role admin**
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil data laporan
$result = mysqli_query($conn, "SELECT * FROM report ORDER BY tanggal DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Laporan User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body>

<div class="container mt-5">
    <h2 class="mb-4">📌 Hasil Laporan User</h2>

    <div class="card shadow p-4">

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th width="60">No</th>
                    <th>Username</th>
                    <th>Isi Laporan</th>
                    <th width="200">Tanggal</th>
                </tr>
            </thead>

            <tbody>
                <?php
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td>
                        <span class="badge bg-primary"><?= $row['username']; ?></span>
                    </td>
                    <td><?= nl2br($row['isi_laporan']); ?></td>
                    <td><?= $row['tanggal']; ?></td>
                </tr>
                <?php 
                    } 
                } else {
                ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        Belum ada laporan yang masuk
                    </td>
                </tr>
                <?php } ?>
            </tbody>
            <a href="dashboard.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
        </table>

    </div>

</div>

</body>
</html>
