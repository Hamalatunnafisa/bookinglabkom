<?php
// index.php - entry, simple redirect demo
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="0;url=dashboard.php">
<title>Redirecting...</title>
</head>
<body>
Redirecting to dashboard...
</body>
</html>
