<?php
require "../../config/config.php";

// === AKSI SELESAI ===
if (isset($_GET['selesai'])) {
    $id = $_GET['selesai'];
    $conn->query("UPDATE booking_lab SET format='selesai' WHERE id='$id'");
    header("Location: kelola_jadwal.php");
    exit;
}

// === AKSI HAPUS ===
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM booking_lab WHERE id='$id'");
    header("Location: kelola_jadwal.php");
    exit;
}

// === AKSI EDIT (PROSES) ===
if (isset($_POST['edit_submit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $nim = $_POST['nim'];
    $nohp = $_POST['nohp'];
    $lab = $_POST['lab'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    $keperluan = $_POST['keperluan'];

    $conn->query("UPDATE booking_lab SET 
        nama='$nama',
        kelas='$kelas',
        nim='$nim',
        nohp='$nohp',
        lab='$lab',
        tanggal='$tanggal',
        jam_mulai='$jam_mulai',
        jam_selesai='$jam_selesai',
        keperluan='$keperluan'
    WHERE id='$id'");

    header("Location: kelola_jadwal.php");
    exit;
}

// === JIKA TOMBOL EDIT DIKLIK (MENAMPILKAN FORM EDIT) ===
$editData = null;
if (isset($_GET['edit'])) {
    $idEdit = $_GET['edit'];
    $editData = $conn->query("SELECT * FROM booking_lab WHERE id='$idEdit'")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Booking Lab Kom – Admin</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body>

<div class="container py-5">

    <div class="card shadow p-4 mb-4">
        <h3 class="mb-3">Kelola Booking Lab Komputer</h3>
        <a href="dashboard.php"><button class="btn btn-secondary">Kembali ke Dashboard</button></a>

        <?php if ($editData): ?>
        <!-- ============= FORM EDIT ============= -->
        <div class="alert alert-info"><b>Edit Data Booking</b></div>

        <form method="POST">
            <input type="hidden" name="id" value="<?= $editData['id'] ?>">

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" value="<?= $editData['nama'] ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>Kelas</label>
                    <input type="text" name="kelas" class="form-control" value="<?= $editData['kelas'] ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>NIM</label>
                    <input type="text" name="nim" class="form-control" value="<?= $editData['nim'] ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label>No HP</label>
                    <input type="text" name="nohp" class="form-control" value="<?= $editData['nohp'] ?>" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label>Lab</label>
                    <input type="text" name="lab" class="form-control" value="<?= $editData['lab'] ?>" required>
                </div>

                <div class="col-md-4 mb-3">
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" value="<?= $editData['tanggal'] ?>" required>
                </div>

                <div class="col-md-2 mb-3">
                    <label>Jam Mulai</label>
                    <input type="time" name="jam_mulai" class="form-control" value="<?= $editData['jam_mulai'] ?>" required>
                </div>

                <div class="col-md-2 mb-3">
                    <label>Jam Selesai</label>
                    <input type="time" name="jam_selesai" class="form-control" value="<?= $editData['jam_selesai'] ?>" required>
                </div>

                <div class="col-md-12 mb-3">
                    <label>Keperluan</label>
                    <textarea name="keperluan" class="form-control" required><?= $editData['keperluan'] ?></textarea>
                </div>
            </div>

            <button type="submit" name="edit_submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="kelola_jadwal.php" class="btn btn-secondary">Batal</a>
        </form>
        <hr>
        <?php endif; ?>

        <?php
        // Ambil semua data booking
        $data = $conn->query("SELECT * FROM booking_lab ORDER BY tanggal, jam_mulai");
        ?>

        <!-- ============= TABEL DATA BOOKING ============= -->
        <table class="table table-bordered table-striped mt-4">
            <thead class="table-dark">
                <tr>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>NIM</th>
                    <th>No HP</th>
                    <th>Lab</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Keperluan</th>
                    <th>Status</th>
                    <th>Format</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
            <?php while($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['kelas'] ?></td>
                    <td><?= $row['nim'] ?></td>
                    <td><?= $row['nohp'] ?></td>
                    <td><?= $row['lab'] ?></td>
                    <td><?= $row['tanggal'] ?></td>
                    <td><?= $row['jam_mulai'] . " - " . $row['jam_selesai'] ?></td>
                    <td><?= $row['keperluan'] ?></td>

                    <td>
                        <?php if ($row['status'] == "approve"): ?>
                            <span class="badge bg-success">Approve</span>
                        <?php elseif ($row['status'] == "reject"): ?>
                            <span class="badge bg-danger">Reject</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php if ($row['format'] == "selesai"): ?>
                            <span class="badge bg-success">Selesai</span>
                        <?php else: ?>
                            <span class="badge bg-info text-dark">Sedang</span>
                        <?php endif; ?>
                    </td>

                    <td class="d-flex gap-2">
                        <a href="?edit=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>

                        <?php if ($row['format'] != "selesai"): ?>
                        <a href="?selesai=<?= $row['id'] ?>" 
                           class="btn btn-success btn-sm"
                           onclick="return confirm('Tandai selesai?')">Selesai</a>
                        <?php endif; ?>

                        <a href="?hapus=<?= $row['id'] ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Hapus data ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>
