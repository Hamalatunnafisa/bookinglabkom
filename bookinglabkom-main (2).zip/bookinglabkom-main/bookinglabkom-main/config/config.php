<?php
$servername = "localhost";
$username = "root";       // username database
$password = "";           // password database
$database = "bookinglabkom"; // nama database

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $database);?>

