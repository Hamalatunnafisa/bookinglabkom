<?php
$servername = "localhost";
$username = "root";       
$password = "";           
$database = "bookinglabkom"; 


$conn = new mysqli($servername, $username, $password, $database);?>

