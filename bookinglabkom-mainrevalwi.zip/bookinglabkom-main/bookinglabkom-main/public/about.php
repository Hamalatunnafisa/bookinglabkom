<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Click.me</title>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
  body {
    margin: 0;
    font-family: 'Roboto', sans-serif;
    background: linear-gradient(135deg, #6a11cb, #2575fc);
    color: #fff;
    overflow-x: hidden;
  }

  header {
    text-align: center;
    padding: 120px 20px 60px 20px;
    animation: fadeIn 2s ease forwards;
  }

  header h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    letter-spacing: 2px;
    animation: slideDown 1.5s ease forwards;
  }

  header p {
    font-size: 1.2rem;
    max-width: 700px;
    margin: auto;
    line-height: 1.6;
    animation: fadeIn 2s 1s ease forwards;
  }

  section {
    padding: 80px 20px;
    max-width: 1000px;
    margin: auto;
    text-align: center;
  }

  section h2 {
    font-size: 2.5rem;
    margin-bottom: 40px;
  }

  .feature {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 40px;
  }

  .card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 30px;
    width: 300px;
    backdrop-filter: blur(10px);
    transition: transform 0.5s, box-shadow 0.5s;
    cursor: pointer;
  }

  .card:hover {
    transform: translateY(-15px) scale(1.05);
    box-shadow: 0 20px 40px rgba(0,0,0,0.3);
  }

  .card h3 {
    margin-bottom: 15px;
  }

  .card p {
    font-size: 1rem;
    line-height: 1.6;
  }

  .btn {
    display: inline-block;
    padding: 15px 30px;
    margin-top: 30px;
    background: #fff;
    color: #2575fc;
    font-weight: bold;
    border-radius: 50px;
    text-decoration: none;
    transition: background 0.3s, color 0.3s;
  }

  .btn:hover {
    background: #2575fc;
    color: #fff;
  }

  p.long-text {
    text-align: justify;
    max-width: 800px;
    margin: 20px auto;
    line-height: 1.8;
  }

  @keyframes fadeIn {
    0% { opacity: 0; transform: translateY(20px);}
    100% { opacity: 1; transform: translateY(0);}
  }

  @keyframes slideDown {
    0% { opacity: 0; transform: translateY(-50px);}
    100% { opacity: 1; transform: translateY(0);}
  }

  .circle {
    position: absolute;
    border-radius: 50%;
    opacity: 0.2;
    animation: float 15s infinite;
  }

  @keyframes float {
    0% { transform: translateY(0) rotate(0deg);}
    50% { transform: translateY(-200px) rotate(180deg);}
    100% { transform: translateY(0) rotate(360deg);}
  }

</style>
</head>
<body>

<!-- Background floating circles -->
<div class="circle" style="width:100px;height:100px;top:10%;left:20%;background:#fff;"></div>
<div class="circle" style="width:150px;height:150px;top:70%;left:80%;background:#fff;"></div>
<div class="circle" style="width:80px;height:80px;top:40%;left:50%;background:#fff;"></div>

<header>
  <h1>Click.me</h1>
  <p>Solusi interaktif untuk mahasiswa meminjam laboratorium komputer dengan cepat, mudah, dan seru. Semua bisa diakses langsung dari browser, kapan pun, di mana pun. Dengan desain modern dan fitur animatif, Click.me membuat pengalaman belajar menjadi lebih menyenangkan dan efisien.</p>
  <a href="#features" class="btn">Lihat Fitur</a>
</header>

<section id="features">
  <h2>Fitur Unggulan</h2>
  <div class="feature">
    <div class="card">
      <h3>Booking Cepat</h3>
      <p>Pinjam lab hanya dengan beberapa klik, tanpa ribet mengisi formulir panjang. Waktu kamu jadi lebih efisien.</p>
    </div>
    <div class="card">
      <h3>Interaktif & Real-time</h3>
      <p>Update ketersediaan lab langsung terlihat, sehingga kamu bisa merencanakan jadwal tanpa menunggu konfirmasi manual.</p>
    </div>
    <div class="card">
      <h3>Notifikasi Pintar</h3>
      <p>Dapatkan pengingat otomatis sebelum jadwal lab dimulai, supaya tidak terlewat dan selalu siap belajar.</p>
    </div>
    <div class="card">
      <h3>Statistik & Riwayat</h3>
      <p>Melihat riwayat booking dan statistik penggunaan lab membantu mahasiswa dan admin memahami pemakaian fasilitas dengan lebih baik.</p>
    </div>
  </div>
</section>

<section>
  <h2>Mengapa Click.me?</h2>
  <p class="long-text">
    Di era digital, semua hal harus cepat, akurat, dan mudah diakses. Click.me hadir untuk menjawab kebutuhan mahasiswa yang ingin meminjam lab komputer tanpa repot. Dengan satu platform, mahasiswa bisa memesan lab, mengecek ketersediaan, mendapatkan pengingat otomatis, dan mengakses riwayat pemakaian. Tidak perlu lagi antri panjang atau menunggu konfirmasi manual dari staf lab.
  </p>
  <p class="long-text">
    Click.me juga mendukung transparansi dan efisiensi. Admin lab dapat mengelola jadwal dengan mudah, melihat statistik penggunaan, dan mengurangi konflik jadwal. Semua ini dilakukan dengan tampilan interaktif, animasi keren, dan navigasi yang intuitif.
  </p>
</section>

<section>
  <h2>Cerita Pengguna</h2>
  <p class="long-text">
    "Sebelumnya saya sering kebingungan mencari jadwal lab yang kosong. Dengan Click.me, semuanya jadi mudah! Cukup buka browser, pilih lab dan jam yang tersedia, dan semua selesai dalam hitungan detik. Saya bahkan bisa mengatur pengingat otomatis sehingga tidak pernah terlambat." – Mahasiswa Teknik Informatika.
  </p>
  <p class="long-text">
    Selain mahasiswa, staf lab juga merasa terbantu karena semua jadwal dan booking tercatat secara digital. Tidak ada lagi tumpang tindih pemakaian, semua transparan dan mudah dipantau.
  </p>
</section>

<section>
  <h2>Bagaimana Cara Memulai?</h2>
  <p class="long-text">
    1. Login menggunakan akun mahasiswa.<br>
    2. Pilih lab yang ingin digunakan.<br>
    3. Tentukan tanggal dan jam penggunaan.<br>
    4. Konfirmasi booking dan tunggu notifikasi.<br>
    5. Datang sesuai jadwal dan mulai belajar!
  </p>
  <a href="login.php" class="btn">Mulai Sekarang</a>
</section>

</body>
</html>
