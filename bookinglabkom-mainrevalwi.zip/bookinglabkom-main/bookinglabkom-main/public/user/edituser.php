<?php
session_start();
require_once "../../config/config.php";
include "check_login.php";

// =======================
// VALIDASI ID
// =======================
if (!isset($_GET['id'])) {
    header("Location: profil.php");
    exit;
}

$id = (int) $_GET['id'];

// =======================
// AMBIL DATA USER
// =======================
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    header("Location: profil.php");
    exit;
}

// =======================
// PROSES UPDATE
// =======================
$error = "";

if (isset($_POST['update'])) {

    $username = $_POST['username'];
    $nama     = $_POST['nama'];
    $nim      = $_POST['nim'];
    $no_hp    = $_POST['no_hp'];

    $password_lama = $_POST['password_lama'];
    $password_baru = $_POST['password_baru'];
    $konfirmasi    = $_POST['konfirmasi'];

    // =======================
    // CEK PASSWORD LAMA
    // =======================
    if (md5($password_lama) !== $user['password']) {
        $error = "Password lama salah!";
    } else {

        // =======================
        // JIKA MAU GANTI PASSWORD
        // =======================
        if (!empty($password_baru)) {

            if ($password_baru !== $konfirmasi) {
                $error = "Konfirmasi password tidak sama!";
            } else {
                $password_hash = md5($password_baru);

                $update = $conn->prepare("
                    UPDATE users SET
                        username = ?,
                        nama = ?,
                        nim = ?,
                        no_hp = ?,
                        password = ?
                    WHERE id = ?
                ");
                $update->bind_param(
                    "sssssi",
                    $username,
                    $nama,
                    $nim,
                    $no_hp,
                    $password_hash,
                    $id
                );
                $update->execute();
            }

        } else {
            // =======================
            // UPDATE TANPA GANTI PASSWORD
            // =======================
            $update = $conn->prepare("
                UPDATE users SET
                    username = ?,
                    nama = ?,
                    nim = ?,
                    no_hp = ?
                WHERE id = ?
            ");
            $update->bind_param(
                "ssssi",
                $username,
                $nama,
                $nim,
                $no_hp,
                $id
            );
            $update->execute();
        }

        if ($error === "") {
            header("Location: profil.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Profil</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container py-5">
<div class="card shadow p-4 mx-auto" style="max-width:500px">

<h4 class="mb-3">Edit Profil</h4>

<?php if ($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">

    <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control"
               value="<?= htmlspecialchars($user['username']) ?>" required>
    </div>

    <div class="mb-3">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control"
               value="<?= htmlspecialchars($user['nama']) ?>" required>
    </div>

    <div class="mb-3">
        <label>NIM</label>
        <input type="text" name="nim" class="form-control"
               value="<?= htmlspecialchars($user['nim']) ?>" required>
    </div>

    <div class="mb-3">
        <label>No HP</label>
        <input type="text" name="no_hp" class="form-control"
               value="<?= htmlspecialchars($user['no_hp']) ?>">
    </div>

    <hr>

    <div class="mb-3">
        <label>Password Lama <span class="text-danger">*</span></label>
        <input type="password" name="password_lama" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Password Baru (opsional)</label>
        <input type="password" name="password_baru" class="form-control">
    </div>

    <div class="mb-3">
        <label>Konfirmasi Password Baru</label>
        <input type="password" name="konfirmasi" class="form-control">
    </div>

    <button name="update" class="btn btn-primary w-100">Simpan</button>
    <a href="profil.php" class="btn btn-secondary w-100 mt-2">Batal</a>

</form>
</div>
</div>
</body>
</html>
