<?php
session_start();
include '../../config/config.php';

$kode = "BK".time();

$sql = "INSERT INTO booking_lab
(nama,nim,nohp,lab,tanggal,jam_mulai,jam_selesai,keperluan,kode_booking,status,format)
VALUES
(
 '{$_SESSION['nama']}',
 '{$_SESSION['nim']}',
 '{$_SESSION['no_hp']}',
 '{$_POST['lab']}',
 '{$_POST['tanggal']}',
 '{$_POST['jam_mulai']}',
 '{$_POST['jam_selesai']}',
 '{$_POST['keperluan']}',
 '$kode',
 'pending',
 'sedang'
)";

mysqli_query($conn,$sql);
header("Location: cek_ketersediaan_view.php");
?>