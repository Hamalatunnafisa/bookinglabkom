<?php 
session_start();
include '../../config/config.php';
include 'check_login.php';

if (!isset($_SESSION['id'])) {
    echo "error: kamu harus login terlebih dahulu.";
    exit;
}

$user_id = $_SESSION['id'];

// ambil nim user
$user_q = $conn->prepare("SELECT nim FROM users WHERE id = ?");
$user_q->bind_param("i", $user_id);
$user_q->execute();
$user = $user_q->get_result()->fetch_assoc();

if (!$user) {
    echo "error: user tidak ditemukan.";
    exit;
}

$nim_user = $user['nim'];

// ambil riwayat booking user
$sql = "SELECT * FROM booking_lab 
        WHERE nim = ?
        ORDER BY tanggal DESC, jam_mulai DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nim_user);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Riwayat Booking Saya</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
.card-booking {
    border-left: 6px solid #0d6efd;
    transition: 0.2s;
}
.card-booking:hover {
    transform: scale(1.01);
    background: #f8f9fa;
}
.label-bold {
    font-weight: bold;
}
</style>
</head>

<body>

<div class="container py-4">
<h3 class="mb-4 fw-bold">Riwayat Booking Saya</h3>

<?php if ($result->num_rows == 0): ?>
    <div class="alert alert-info">Anda belum memiliki riwayat booking.</div>
<?php endif; ?>

<?php while ($row = $result->fetch_assoc()) : ?>
<div class="card mb-3 card-booking shadow-sm">
<div class="card-body">

<!-- STATUS -->
<div class="text-end mb-2">
<?php if ($row['status'] == 'pending'): ?>
    <span class="badge bg-warning text-dark">Pending</span>
<?php elseif ($row['status'] == 'approve'): ?>
    <span class="badge bg-success">Disetujui</span>
<?php elseif ($row['status'] == 'reject'): ?>
    <span class="badge bg-danger">Ditolak</span>
<?php endif; ?>
</div>

<h5 class="fw-bold"><?= htmlspecialchars($row['lab']); ?></h5>

<p class="mb-1"><span class="label-bold">Tanggal:</span> <?= $row['tanggal']; ?></p>
<p class="mb-1"><span class="label-bold">Jam:</span> <?= $row['jam_mulai']; ?> - <?= $row['jam_selesai']; ?></p>
<p class="mb-1"><span class="label-bold">Keperluan:</span> <?= htmlspecialchars($row['keperluan']); ?></p>

<p class="mt-3 mb-1"><span class="label-bold">Kode Booking:</span></p>
<div class="p-2 bg-light border rounded"><?= $row['kode_booking']; ?></div>

<!-- TOMBOL QR -->
<a href="qrcode.php?
nama=<?= urlencode($row['nama']); ?>
&nim=<?= urlencode($row['nim']); ?>
&lab=<?= urlencode($row['lab']); ?>
&tanggal=<?= urlencode($row['tanggal']); ?>
&waktu=<?= urlencode($row['jam_mulai'].' - '.$row['jam_selesai']); ?>"
&kode_booking=<?= urlencode($row['kode_booking']); ?>"
class="btn btn-primary mt-3">
    Lihat QR
</a>

<a href="dashboard.php" class="btn btn-secondary mt-3">Kembali</a>

</div>
</div>
<?php endwhile; ?>

</div>
</body>
</html>
