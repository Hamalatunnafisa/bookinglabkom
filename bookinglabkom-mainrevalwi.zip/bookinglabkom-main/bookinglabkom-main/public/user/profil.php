<?php 
session_start();
include 'check_login.php';
require_once '../../config/config.php';

$user_id = $_SESSION['id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$users = $result->fetch_assoc();

if (!$users) {
    echo "error: user tidak ditemukan.";
    exit;
}

// ambil inisial nama
$inisial = strtoupper(substr($users['nama'], 0, 1));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Saya</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
body {
    background: linear-gradient(135deg, #e3f2fd, #f8f9fa);
}

.profile-container {
    max-width: 500px;
    margin: 60px auto;
    padding: 30px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.12);
}

/* AVATAR */
.avatar {
    width: 120px;
    height: 120px;
    margin: 0 auto 15px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0d6efd, #6ea8fe);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 48px;
    font-weight: bold;
    color: white;
}

.profile-header {
    text-align: center;
    margin-bottom: 30px;
}

.profile-header h2 {
    margin-bottom: 5px;
}

.profile-info label {
    font-weight: 600;
    color: #555;
}

.profile-info p {
    font-size: 1.05rem;
    margin-bottom: 15px;
}

/* BUTTON */
.btn-group-custom {
    display: flex;
    gap: 12px;
    margin-top: 30px;
}

.btn-group-custom a {
    flex: 1;
}
</style>
</head>

<body>

<div class="profile-container">

    <!-- AVATAR -->
    <div class="avatar">
        <?= $inisial ?>
    </div>

    <div class="profile-header">
        <h2><?= htmlspecialchars($users['nama']) ?></h2>
        <p class="text-muted">Profil Pengguna</p>
    </div>

    <div class="profile-info">
        <label>NIM</label>
        <p><?= htmlspecialchars($users['nim']) ?></p>

        <label>No HP</label>
        <p><?= htmlspecialchars($users['no_hp']) ?></p>

        <label>Username</label>
        <p><?= htmlspecialchars($users['username']) ?></p>
    </div>

    <!-- BUTTON -->
    <div class="btn-group-custom">
        <a href="edituser.php?id=<?= $users['id'] ?>" class="btn btn-primary">
    Edit User
</a>
        <a href="dashboard.php" class="btn btn-secondary">
            Kembali
        </a>
    </div>

</div>

</body>
</html>
