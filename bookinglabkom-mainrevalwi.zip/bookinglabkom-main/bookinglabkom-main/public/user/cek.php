<?php
session_start();
require_once '../../config/config.php';
include 'check_login.php';

/* =========================
   MODE JSON (UNTUK FETCH)
========================= */
if (isset($_GET['tanggal'])) {
    header('Content-Type: application/json');

    $tanggal = $_GET['tanggal'];

    $sql = "SELECT 
                lab, 
                TIME_FORMAT(jam_mulai,'%H:%i') AS jam_mulai,
                TIME_FORMAT(jam_selesai,'%H:%i') AS jam_selesai
            FROM booking_lab
            WHERE tanggal = '$tanggal'
            AND status IN ('pending','approve')";

    $result = mysqli_query($conn, $sql);
    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    echo json_encode($data);
    exit;
}

/* =========================
   MODE SIMPAN BOOKING
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $kode = 'BK' . time();

    $nama  = $_SESSION['nama'];
    $nim   = $_SESSION['nim'];
    $nohp  = $_SESSION['nohp'] ?? '-';
    $kelas = '-';

    $lab        = $_POST['lab'];
    $tanggal    = $_POST['tanggal'];
    $mulai      = $_POST['jam_mulai'];
    $selesai    = $_POST['jam_selesai'];
    $keperluan  = $_POST['keperluan'];

    $sql = "INSERT INTO booking_lab
            (nama, nim, kelas, nohp, lab, tanggal, jam_mulai, jam_selesai, keperluan, kode_booking, status, format)
            VALUES
            ('$nama','$nim','$kelas','$nohp','$lab','$tanggal','$mulai','$selesai','$keperluan','$kode','pending','sedang')";

    mysqli_query($conn, $sql);

    header("Location: riwayat.php");
    exit;
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Cek & Booking Lab</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.slot-btn {
    font-size: 13px;
    padding: 6px 10px;
    margin: 4px;
    border-radius: 6px;
    cursor: pointer;
}

.slot-available {
    background: #198754;
    color: #fff;
    border: none;
}

.slot-used {
    background: #e9ecef;       /* abu abu */
    color: #6c757d;
    border: 2px solid #dc3545; /* border merah */
    cursor: not-allowed;
}
</style>

</head>

<body>

<div class="container py-5">
<div class="card p-4 shadow mx-auto" style="max-width:900px;">

<h3 class="mb-3">Cek & Booking Lab</h3> 

<input type="date" id="cek_date" class="form-control mb-4"
value="<?= date('Y-m-d'); ?>"> <br>
<a href="dashboard.php" class="btn btn-secondary">Kembali ke Dashboard</a>

<div id="cek_result"></div>

</div>
</div>

<!-- MODAL -->
<div class="modal fade" id="modalBooking" tabindex="-1">
<div class="modal-dialog">
<div class="modal-content">

<form method="POST">
<div class="modal-header">
<h5 class="modal-title">Form Booking</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="hidden" name="lab" id="form_lab">
<input type="hidden" name="tanggal" id="form_tanggal">
<input type="hidden" name="jam_mulai" id="form_mulai">
<input type="hidden" name="jam_selesai" id="form_selesai">

<textarea name="keperluan" class="form-control" placeholder="Keperluan" required></textarea>
</div>

<div class="modal-footer">
<button class="btn btn-primary">Booking</button>
</div>
</form>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
const labs = ["Lab Komputer 1","Lab Komputer 2","Lab Komputer 3","Lab Komputer 4"];
const slots = [
 ["06:00","07:30"],["07:30","08:30"],["08:30","10:00"],
 ["10:00","11:30"],["13:00","14:30"],["14:30","16:00"],
 ["16:00","17:30"],["17:30","19:00"],["19:00","20:30"]
];

async function render(date){
 const res = await fetch("cek.php?tanggal=" + date);
 const data = await res.json();

 const out = document.getElementById("cek_result");
 out.innerHTML = "";

 labs.forEach(lab => {
   let html = `<div class="mb-4 p-3 border rounded">
                 <h5>${lab}</h5>`;

   slots.forEach(s => {

     const terpakai = data.some(b =>
        b.lab === lab &&
        b.jam_mulai === s[0] &&
        b.jam_selesai === s[1]
     );

     if (terpakai) {
       html += `<button class="slot-btn slot-used" disabled>
                  ${s[0]} - ${s[1]}
                </button>`;
     } else {
       html += `<button class="slot-btn slot-available"
                  onclick="openBooking('${lab}','${s[0]}','${s[1]}')">
                  ${s[0]} - ${s[1]}
                </button>`;
     }

   });

   html += `</div>`;
   out.innerHTML += html;
 });
}

function openBooking(lab,mulai,selesai){
 document.getElementById('form_lab').value = lab;
 document.getElementById('form_tanggal').value = cek_date.value;
 document.getElementById('form_mulai').value = mulai;
 document.getElementById('form_selesai').value = selesai;
 new bootstrap.Modal(document.getElementById('modalBooking')).show();
}

cek_date.onchange = () => render(cek_date.value);
window.onload = () => render(cek_date.value);
</script>


</body>
</html>
