<?php
session_start();
require_once "../../config/config.php";

// Jika user belum login
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}

// Username otomatis dari session
$username = $_SESSION['username'];

// ==== PROSES SIMPAN LAPORAN (DALAM FILE INI JUGA) ====
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $isi_laporan = $_POST['isi_laporan'];

    $query = "INSERT INTO report (username, isi_laporan)
              VALUES ('$username', '$isi_laporan')";

    if(mysqli_query($conn, $query)){
        echo "<script>alert('Laporan berhasil dikirim!');</script>";
    } else {
        echo "<script>alert('Gagal menyimpan laporan');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kirim Laporan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <div class="card p-4 shadow">
        <h3>Kirim Laporan / Evaluasi</h3>
        <hr>

        <!-- FORM -->
        <form method="POST">

            <div class="mb-3">
                <label>Isi Laporan Anda :</label>
                <textarea name="isi_laporan" class="form-control" rows="5" required></textarea>
            </div>

            <button class="btn btn-primary">Kirim Laporan</button>
            <a href="dashboard.php"><button type="button" class="btn btn-secondary">Kembali ke Dashboard</button></a>
        </form>

    </div>
</div>

</body>
</html>
