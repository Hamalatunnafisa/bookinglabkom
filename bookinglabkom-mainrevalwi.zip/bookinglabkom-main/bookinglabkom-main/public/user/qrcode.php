<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: ../login.php");
    exit;
}

$nama    = htmlspecialchars($_GET['nama'] ?? '');
$nim     = htmlspecialchars($_GET['nim'] ?? '');
$lab     = htmlspecialchars($_GET['lab'] ?? '');
$tanggal = htmlspecialchars($_GET['tanggal'] ?? '');
$waktu   = htmlspecialchars($_GET['waktu'] ?? '');
$kode_booking = $_GET['kode_booking'] ?? '';
$kode_booking = htmlspecialchars($kode_booking);

$qr_text = "Kode Booking: $kode_booking
Nama: $nama
NIM: $nim
Lab: $lab
Tanggal: $tanggal
Waktu: $waktu";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kode Booking</title>

<link rel="stylesheet" href="../../public/assets/css/style.css">

<style>
body {
    display: flex;
    justify-content: center;
    padding: 50px 20px;
    background: linear-gradient(135deg, #87CEEB, #B0E0E6);
    min-height: 100vh;
    font-family: 'Segoe UI', sans-serif;
}

.qr-card {
    background: white;
    width: 400px;
    padding: 2rem;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,.15);
    animation: fadeIn .5s ease;
}

.qr-card h2 {
    text-align: center;
    margin-bottom: 1rem;
}

.info {
    font-size: 15px;
    line-height: 1.7;
}

#qrcode img {
    width: 200px;
    margin: 20px auto;
    display: block;
}

.btn {
    width: 100%;
    margin-top: 10px;
}
</style>
</head>

<body>

<div class="qr-card">
    <h2>Kode Booking</h2>

   <div class="info">
    <b>Kode Booking:</b> <?= $kode_booking ?><br>
    <b>Nama:</b> <?= $nama ?><br>
    <b>NIM:</b> <?= $nim ?><br>
    <b>Lab:</b> <?= $lab ?><br>
    <b>Tanggal:</b> <?= $tanggal ?><br>
    <b>Waktu:</b> <?= $waktu ?><br>
</div>


    <div id="qrcode"></div>

    <button class="btn btn-secondary" onclick="window.history.back()">Kembali</button>
    <button class="btn btn-primary" onclick="window.print()">Print QR</button>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
new QRCode(document.getElementById("qrcode"), {
    text: `<?= $qr_text ?>`,
    width: 200,
    height: 200
});
</script>

</body>
</html>
