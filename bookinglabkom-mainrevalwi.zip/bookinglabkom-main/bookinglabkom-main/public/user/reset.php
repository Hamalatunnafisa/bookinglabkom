<?php ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reset Data</title>
</head>

<body onload="resetBooking()">

<script src="assets/js/app.js"></script>

</body>
</html>
