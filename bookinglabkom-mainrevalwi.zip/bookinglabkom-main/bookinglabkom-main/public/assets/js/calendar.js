document.getElementById("calendar").innerHTML = `
    <div style="padding:15px;background:white;border-radius:10px;border:1px solid #eee;text-align:center;">
        <h4>Kalender Coming Soon</h4>
        <p style="opacity:.7;">(Bisa dihubungkan dengan database)</p>
    </div>
`;
