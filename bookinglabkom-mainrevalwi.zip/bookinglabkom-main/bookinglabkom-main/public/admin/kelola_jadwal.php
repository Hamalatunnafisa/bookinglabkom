<?php
require "../../config/config.php";

/* =========================
   TANDAI SELESAI
========================= */
if (isset($_GET['selesai'])) {
    $id = $_GET['selesai'];
    $conn->query("UPDATE booking_lab SET format='selesai' WHERE id='$id'");
    header("Location: kelola_jadwal.php");
    exit;
}

/* =========================
   MODE EDIT
========================= */
if (isset($_POST['edit_submit'])) {
    $id = $_POST['id'];

    $conn->query("UPDATE booking_lab SET 
        nama='{$_POST['nama']}',
        kelas='{$_POST['kelas']}',
        nim='{$_POST['nim']}',
        nohp='{$_POST['nohp']}',
        lab='{$_POST['lab']}',
        tanggal='{$_POST['tanggal']}',
        jam_mulai='{$_POST['jam_mulai']}',
        jam_selesai='{$_POST['jam_selesai']}',
        keperluan='{$_POST['keperluan']}'
    WHERE id='$id'");

    header("Location: kelola_jadwal.php");
    exit;
}

/* =========================
   DATA EDIT
========================= */
$editData = null;
if (isset($_GET['edit'])) {
    $idEdit = $_GET['edit'];
    $editData = $conn->query(
        "SELECT * FROM booking_lab WHERE id='$idEdit' AND format='sedang'"
    )->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Booking Lab – Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<body>
<div class="container py-5">

<div class="card shadow p-4">
<h3 class="mb-3">Kelola Booking Lab Komputer</h3>
<a href="dashboard.php" class="btn btn-secondary mb-3">Kembali ke Dashboard</a>

<!-- ================= EDIT FORM ================= -->
<?php if ($editData): ?>
<div class="alert alert-info"><b>Edit Booking</b></div>

<form method="POST">
<input type="hidden" name="id" value="<?= $editData['id'] ?>">

<div class="row">
<div class="col-md-6 mb-3">
<label>Nama</label>
<input type="text" name="nama" class="form-control" value="<?= $editData['nama'] ?>" required>
</div>

<div class="col-md-6 mb-3">
<label>Kelas</label>
<input type="text" name="kelas" class="form-control" value="<?= $editData['kelas'] ?>" required>
</div>

<div class="col-md-6 mb-3">
<label>NIM</label>
<input type="text" name="nim" class="form-control" value="<?= $editData['nim'] ?>" required>
</div>

<div class="col-md-6 mb-3">
<label>No HP</label>
<input type="text" name="nohp" class="form-control" value="<?= $editData['nohp'] ?>" required>
</div>

<div class="col-md-4 mb-3">
<label>Lab</label>
<input type="text" name="lab" class="form-control" value="<?= $editData['lab'] ?>" required>
</div>

<div class="col-md-4 mb-3">
<label>Tanggal</label>
<input type="date" name="tanggal" class="form-control" value="<?= $editData['tanggal'] ?>" required>
</div>

<div class="col-md-2 mb-3">
<label>Jam Mulai</label>
<input type="time" name="jam_mulai" class="form-control" value="<?= $editData['jam_mulai'] ?>" required>
</div>

<div class="col-md-2 mb-3">
<label>Jam Selesai</label>
<input type="time" name="jam_selesai" class="form-control" value="<?= $editData['jam_selesai'] ?>" required>
</div>

<div class="col-md-12 mb-3">
<label>Keperluan</label>
<textarea name="keperluan" class="form-control" required><?= $editData['keperluan'] ?></textarea>
</div>
</div>

<button type="submit" name="edit_submit" class="btn btn-primary">Simpan</button>
<a href="kelola_jadwal.php" class="btn btn-secondary">Batal</a>
</form>
<hr>
<?php endif; ?>

<!-- ================= DATA TABEL ================= -->
<?php
$data = $conn->query("
    SELECT * FROM booking_lab 
    WHERE format='sedang'
    ORDER BY tanggal, jam_mulai
");
?>

<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
<th>Nama</th>
<th>Kelas</th>
<th>NIM</th>
<th>Lab</th>
<th>Tanggal</th>
<th>Jam</th>
<th>Status</th>
<th>Aksi</th>
</tr>
</thead>

<tbody>
<?php while($row = $data->fetch_assoc()): ?>
<tr>
<td><?= $row['nama'] ?></td>
<td><?= $row['kelas'] ?></td>
<td><?= $row['nim'] ?></td>
<td><?= $row['lab'] ?></td>
<td><?= $row['tanggal'] ?></td>
<td><?= $row['jam_mulai']." - ".$row['jam_selesai'] ?></td>

<td>
<?php if ($row['status'] == 'approve'): ?>
<span class="badge bg-success">Approve</span>
<?php elseif ($row['status'] == 'reject'): ?>
<span class="badge bg-danger">Reject</span>
<?php else: ?>
<span class="badge bg-warning text-dark">Pending</span>
<?php endif; ?>
</td>

<td class="d-flex gap-2">
<a href="?edit=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>

<a href="?selesai=<?= $row['id'] ?>"
   onclick="return confirm('Tandai booking ini selesai?')"
   class="btn btn-success btn-sm">
   Selesai
</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

</div>
</div>
</body>
</html>
