<?php
session_start();
require "../../config/config.php";
include "chek_login.php";

// =======================
// VALIDASI ID
// =======================
if (!isset($_GET['id'])) {
    header("Location: user.php");
    exit;
}

$id = $_GET['id'];

// =======================
// AMBIL DATA USER
// =======================
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    // Jika user tidak ditemukan
    header("Location: user.php");
    exit;
}

// =======================
// PROSES UPDATE
// =======================
if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $nama     = $_POST['nama'];
    $nim      = $_POST['nim'];
    $no_hp     = $_POST['no_hp'];
    $role     = $_POST['role'];
    $status   = $_POST['status'];

    $update = $conn->prepare("
        UPDATE users SET
            username = ?,
            nama = ?,
            nim = ?,
            no_hp = ?,
            role = ?,
            status = ?
        WHERE id = ?
    ");

    $update->bind_param(
        "ssssssi",
        $username,
        $nama,
        $nim,
        $no_hp,
        $role,
        $status,
        $id
    );

    $update->execute();

    header("Location: user.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container py-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">Edit User</h3>

        <form method="POST">
            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control"
                       value="<?= htmlspecialchars($user['username']) ?>" required>
            </div>

            <div class="mb-3">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control"
                       value="<?= htmlspecialchars($user['nama']) ?>" required>
            </div>

            <div class="mb-3">
                <label>NIM</label>
                <input type="text" name="nim" class="form-control"
                       value="<?= htmlspecialchars($user['nim']) ?>" required>
            </div>

            <div class="mb-3">
                <label>No HP</label>
                <input type="text" name="no_hp" class="form-control"
                       value="<?= htmlspecialchars($user['no_hp']) ?>">
            </div>

            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control">
                    <option value="user" <?= $user['role']=='user'?'selected':'' ?>>User</option>
                    <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="active" <?= $user['status']=='active'?'selected':'' ?>>Active</option>
                    <option value="inactive" <?= $user['status']=='inactive'?'selected':'' ?>>Inactive</option>
                </select>
            </div>

            <button name="update" class="btn btn-primary">Simpan</button>
            <a href="user.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

</body>
</html>
